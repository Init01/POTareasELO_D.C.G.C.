import java.io.*;
import java.util.Scanner;

public class PhysicsLab {

   public static void main(String[] args) {
    
      MyWorld world = new MyWorld(System.out);
         
      Scanner s = new Scanner (System.in);
      System.out.print("Ingrese delta: ");
      while(!s.hasNextFloat()){
        s.nextLine();
        System.out.print("Ese no es un real, ingrese un número real por favor:");
      }
      float deltaTime = s.nextFloat();
      System.out.print("Ingrese Tiempo a simular: ");
       while(!s.hasNextFloat()){
        s.nextLine();
        System.out.print("Ese no es un real, ingrese un número real por favor:");
      }
      float endTime = s.nextFloat();
      System.out.print("Ingrese Tiempo entre escrituras en el salida del estado del sistema: ");
       while(!s.hasNextFloat()){
        s.nextLine();
        System.out.print("Ese no es un real, ingrese un número real por favor:");
      }
      float samplingTime = s.nextFloat();

      double mass = 1.0;      // 1 [kg] 
      double radius = 0.1;    // 10 [cm] 
      double position = 1.0;  // 1 [m] 
      double speed = 0.5;     // 0.5 [m/s]
      Ball b0 = new Ball(mass, radius, position, speed);
      Ball b1 = new Ball(mass, radius, 3.00, 0);
      world.addElement(b0);
      world.addElement(b1);
      world.simulate(deltaTime, endTime, samplingTime); // delta time[s], total simulation time [s].
   }
}

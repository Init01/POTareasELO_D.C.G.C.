

import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import java.util.*;
import javax.swing.JPanel;
import java.awt.event.*;
import java.awt.*;
/** 
 * Implementacion de keylistener
 */
public class KeyListener extends KeyAdapter {
   private MyWorld world;
   private PhysicsElement currentElement;
   private ArrayList<PhysicsElement> elements = new ArrayList<PhysicsElement>();
   private ArrayList<SpringAttachable> el_a = new ArrayList<SpringAttachable>();
   public KeyListener (MyWorld w){
      world = w;
      elements = w.getPhysicsElements();
   }
 /** 
 * keyTyped
 * @param e
 */
    public void keyTyped(KeyEvent e) {
    }
/** 
 * keyPressed selecciona elementos al pulsar "n"
 * @param e
 */
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == 78) {
            for (PhysicsElement elem : elements) {
                elem.setSelected();
            }
        }
    }
/** 
 * keyReleased selecciona elementos al soltar "n"
 * @param e
 */

    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == 78) {
            for (PhysicsElement elem : elements) {
                elem.setReleased();
            }
        }
    }
}


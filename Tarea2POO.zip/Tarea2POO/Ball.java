

import java.util.*;
import java.awt.*;

public class Ball extends PhysicsElement implements Simulateable, SpringAttachable {
   private static int id=0;  // Ball identification number
   private final double mass;
   private final double radius;
   private double pos_t;     // current position at time t
   private double pos_tPlusDelta;  // next position in delta time in future
   private double speed_t;   // speed at time t
   private double speed_tPlusDelta;   // speed in delta time in future
   private double a_t;    // acceleration at time t
   private double a_tMinusDelta;  // acceleration delta time ago;
   private BallView view;  // Ball view of Model-View-Controller design pattern
   private ArrayList<Spring> springs;  // ArrayList can grow, arrays cannot. 
   
   private Ball(){   // nobody can create a block without state
     this(1.0,0.1,0,0);
   }
/** 
 * Constructor Ball.  Initializes a new Ball.  
 * @param mass	masa de la bola
 * @param radius radio de la bola
 * @param position posicion de la bola
 * @param speed Velocidad de la bola
 */
   public Ball(double mass, double radius, double position, double speed){
      super(id++);
      this.mass = mass;
      this.radius = radius;
      pos_t = position;
      speed_t = speed;
      view = new BallView(this);
   }

  /**
 * Retorna la masa de la bola
 * @return Masa
 */
   public double getMass() {
      return mass;
   }
 /**
 * Retorna el radio de la bola
 * @return radius
 */
   public double getRadius() {
      return radius;
   }
  /**
 * Retorna la posicion la bola
 * @return pos_t
 */
   public double getPosition() {
      return pos_t;
   }
  /**
 * Retorna la velocidad de la bola
 * @return speed_t
 */
   public double getSpeed() {
      return speed_t;
   }
   
/** 
 * Fuerza Aplicada sobre la bola  
 * @return Fuerza neta aplicada sobre la bola
 *               
 */

   private double getNetForce() {
       if (springs != null) {
        for (Spring s:springs) {
           if (s.a_end != null && s.b_end != null)
               return s.getForce(this);
        }
       }
       return 0;
   }

   /*public void computeNextState(double delta_t, MyWorld world) {
     Ball b;  // Assumption: on collision we only change speed.   
     if ((b=world.findCollidingBall(this))!= null){ /* elastic collision */
     /*   speed_tPlusDelta=(speed_t*(mass-b.getMass())+2*b.getMass()*b.getSpeed())/(mass+b.getMass());
        pos_tPlusDelta = pos_t;
     } else {
        speed_tPlusDelta = speed_t;
        pos_tPlusDelta = pos_t + speed_t*delta_t;
     }
   }*/

/** 
 * Computa nuevo estado  
 * @param delta_t Espacio de tiempo de simulacion
 * @param world Referencia a otra bola de world
 */
   public void computeNextState(double delta_t, MyWorld world) {
     Ball b;  // Assumption: on collision we only change speed.  
     if ((b=world.findCollidingBall(this))!= null) { /* elastic collision */
        speed_tPlusDelta=(speed_t*(mass-b.getMass())+2*b.getMass()*b.getSpeed())/(mass+b.getMass());
        pos_tPlusDelta = pos_t;
        a_t = getNetForce() / mass;
        pos_tPlusDelta = pos_t;
     } else {
        a_t = getNetForce() / mass;
        pos_tPlusDelta = 0.5*a_t*delta_t*delta_t + speed_t*delta_t + pos_t;
        speed_tPlusDelta = a_t*delta_t + speed_t;
     }
   }
/** 
 * Deteccion de colision  
 * @param b objeto bola
 * @return True or False dependiendo si existe colision    
 */
   
   public boolean collide(Ball b) {
     if (this == b) return false;
     boolean closeEnougth = Math.abs(getPosition()-b.getPosition()) < (getRadius()+b.getRadius());
     boolean approaching = getSpeed() > b.getSpeed();
     if (b.getPosition() < getPosition())
        approaching = getSpeed() < b.getSpeed();
     return closeEnougth && approaching;
   }

/** 
 * Actualizacion de estado  
 */
   
   public void updateState(){
     pos_t = pos_tPlusDelta;
     speed_t = speed_tPlusDelta;
   }

/** 
 * Actualizacion de vista de la bola  
 * @param g objeto bola de interfaz grafica
 */
   public void updateView (Graphics2D g) {   // NEW
     view.updateView(g);  // update this Ball's view in Model-View-Controller design pattern     
   }

/** 
 * contains
 * @param x 
 * @param y 
 * @return view.contains(x,y) 
 */
   public boolean contains(double x, double y) {
      return view.contains(x,y);
   }

/** 
 * setSelected
 */

   public void setSelected(){
      view.setSelected();
   }

/** 
 * setReleased
 */
   public void setReleased(){
      view.setReleased();
   }
/** 
 * dragTo
 * @param x posision de bola en interfaz grafica
 */
   public void dragTo(double x){
      pos_t=x;
   }
/** 
 * Descripcion bola
 * @return  "Ball_" + getId()+":x"
 */
   public String getDescription() {
     return "Ball_" + getId()+":x";
   }
/** 
 * Estado bola
 * @return posicion bola
 */
   public String getState() {
     return getPosition()+"";
   }
   
/** 
 * Conexion a resorte
 * @param s1 objeto resorte
 */
   public void attachSpring(Spring s1) {
       springs = new ArrayList<Spring>();
       springs.add(s1);
       if (this.equals(s1.a_end)) {
           this.pos_t = s1.a_end.getPosition();
       }
       if (this.equals(s1.b_end)) {
           this.pos_t = s1.b_end.getPosition();
       } 
   }
/** 
 * desconexion a resorte
 */
   public void detachSpring(Spring s1) {
       
   }
}

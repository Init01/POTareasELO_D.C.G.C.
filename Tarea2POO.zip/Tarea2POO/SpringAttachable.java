/** 
 * Interfaz Springattachable
 */

interface SpringAttachable {
  void attachSpring(Spring s);
  void detachSpring(Spring s);
  double getPosition();
  
}

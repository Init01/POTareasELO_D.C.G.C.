

import java.awt.*;
/** 
 * Clase Elementos fisicos
 */
public abstract class PhysicsElement {
   private final int myId; /* to identify each element within its category */
  /** 
 * Elementos fisicos
 * @param id
 */
   protected PhysicsElement( int id){
      myId = id;
   }

/** 
 * retorno de identificacion
 * @return myId
 */
   protected int getId() {
      return myId;
   }
   public abstract String getDescription();
   public abstract String getState();
   public abstract void updateView(Graphics2D g);
   public abstract boolean contains(double x, double y);
   public abstract void setSelected();
   public abstract void setReleased();
   public abstract void dragTo(double x);
}

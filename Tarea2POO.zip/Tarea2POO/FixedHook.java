

import java.util.*;
import java.awt.*;

public class FixedHook extends PhysicsElement implements SpringAttachable, Simulateable {
   private static int id=0;  // Ball identification number
   private final double radius;
   private double pos_t;     // current position at time t
   private ArrayList<Spring> springs;  // ArrayList can grow, arrays cannot. 
   private FixedHookView view;

   private FixedHook() {   // nobody can create a block without state
     this(0.1,0);
   }
/** 
 * Creacion de un nuevo Fixed Hook 
 * @param radius radio de FixedHook
 * @param position posicion de FixedHook
 */
   public FixedHook(double radius, double position){
      super(id++);
      this.radius = radius;
      pos_t = position;
      view = new FixedHookView(this);
   }
/** 
 * Obtener radio Fixed Hook 
 * @return radius radio de Fixed Hook 
 */
   public double getRadius() {
      return radius;
   }
/** 
 * Computa nuevo estado  
 * @param delta_t Espacio de tiempo de simulacion
 * @param world Referencia a otra bola de world
 */
   public void computeNextState(double delta_t, MyWorld world) {

   }
/** 
 * Actualiza nuevo estado  
 */
   public void updateState() {

   }
  /** 
 * Descripcion Fixed Hook
 * @return  "FixedHook_" + getId() + ":x"
 */
   public String getDescription() {
        return "FixedHook_" + getId() + ":x";
   }
   public String getState() {
        return String.valueOf(pos_t);
   }
/** 
 * Obtener posicion
 * @return pos_t
 */
    public double getPosition() {
        return pos_t;
    }
/** 
 * Conexion a resorte
 * @param s1 objeto resorte
 */
    public void attachSpring(Spring s1) {
        springs = new ArrayList<Spring>();
        springs.add(s1);
        if (this.equals(s1.a_end)) {
            this.pos_t = s1.a_end.getPosition();
        }
        if (this.equals(s1.b_end)) {
            this.pos_t = s1.b_end.getPosition();
        }
    }
/** 
 * desconexion a resorte

 */
    public void detachSpring(Spring s1) {
       
    }
    
/** 
 * Actualizacion de vista del Fixed Hook
 * @param g objeto FixedHook de interfaz grafica
 */
   public void updateView (Graphics2D g) {   // NEW
     view.updateView(g);  // update this Ball's view in Model-View-Controller design pattern     
   }
/** 
 * contains
 * @param x 
 * @param y 
 * @return view.contains(x,y) 
 */
   public boolean contains(double x, double y) {
      return view.contains(x,y);
   }

 /** 
 * setSelected
 */
   public void setSelected(){
      view.setSelected();
   }
/** 
 * setReleased
 */

   public void setReleased(){
      view.setReleased();
   }
/** 
 * dragTO
 * @param x posicion al arrastar en interfaz grafica
 */

   public void dragTo(double x){
      pos_t=x;
   }
}

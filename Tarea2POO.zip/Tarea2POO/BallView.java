

import java.awt.*;
import java.awt.geom.*;
/** 
 * Vista de bola 
 */
public class BallView {
   private Color color = Color.BLUE;
   private Ellipse2D.Double shape = null;
   private Ball ball;
 /** 
 * Creacion de objeto en interfaz grafica
 * @param b bola   
 */
   public BallView (Ball b){
       ball = b;
       shape = new Ellipse2D.Double(ball.getPosition()-ball.getRadius(), -ball.getRadius(), 2*ball.getRadius(), 2*ball.getRadius()); 
   }
/** 
 * contains
 * @param x 
 * @param y 
 * @return view.contains(x,y) 
 */
   public boolean contains (double x, double y){
       return shape.getBounds2D().contains(x, y);
       //return shape.x <= x && shape.y <= y;
   }
/** 
 * setSelected
 * cambia color
 */
   public void setSelected (){
      color = Color.RED;
   }
/** 
 * setSelected
 * cambia color
 */
   public void setReleased() {
      color = Color.BLUE;
   }
/** 
 * Actualizacion de vista en la interfaz grafica
 * @param g
 */
   void updateView(Graphics2D g) {
      double radius = ball.getRadius();
      shape.setFrame(ball.getPosition()-radius, -radius, 2*radius, 2*radius);
      g.setColor(color);
      g.fill(shape);
   }

}

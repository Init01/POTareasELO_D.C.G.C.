

import java.awt.event.*; 
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
/** 
 * LabMenuListener 
 */
public class LabMenuListener implements ActionListener {
   private MyWorld  world;
   public LabMenuListener (MyWorld  w){
      world = w;
   }
/** 
 * actionPerformed ejecucuion de acciones y creacion de objetos
 * @param e 
 */

   public void actionPerformed(ActionEvent e) {
      JMenuItem menuItem = (JMenuItem)(e.getSource());
      String text = menuItem.getText();
      
      // Actions associated to main manu options
      if (text.equals("My scenario")) {  // here you define Etapa2's configuration
          double mass = 1.0;      // 1 [kg] 
          double radius = 0.1;    // 10 [cm] 
          double position = 0.0;  // 1 [m] 
          double speed = 0.5;     // 0.5 [m/s]
          Ball b0 = new Ball(mass, radius, 1.0, 0);
          Ball b1 = new Ball(mass, radius, 1.5, 0);
          Ball b2 = new Ball(mass, radius, 2.0, 0);
          FixedHook h0 = new FixedHook(0.1,0.5);
          FixedHook h1 = new FixedHook(0.1,3.0);
          Spring s0 = new Spring(1, 1);
          Spring s1 = new Spring(1, 1);
          s0.attachAend(h0);
          s0.attachBend(b0);
          s1.attachAend(b2);
          s1.attachBend(h1);
          world.addElement(h0);
          world.addElement(h1);
          world.addElement(s0);
          world.addElement(s1);
          world.addElement(b0);
          world.addElement(b1);
          world.addElement(b2);
      }
      if (text.equals("Ball")) {
          double mass = 1.0;      // 1 [kg] 
          double radius = 0.1;    // 10 [cm] 
          double position = 0.0;  // 1 [m] 
          double speed = 0.5;     // 0.5 [m/s]
          Ball b0 = new Ball(mass, radius, -0.3, 0);
          world.addElement(b0);
          world.repaintView();
      }
      if (text.equals("Fixed Hook")) {
          FixedHook h0 = new FixedHook(0.1,-0.3);
          world.addElement(h0);
          world.repaintView();
      } 
      if (text.equals("Spring")) {
          Spring s0 = new Spring(1, 1);
          world.addElement(s0);
          world.repaintView();
      }
      
      // Actions associated to MyWorld submenu
      if (text.equals("Start")) {
          world.start();
      }
      if (text.equals("Stop")) {
          world.stop();
      }
      if (text.equals("Delete all")) {
          world.delete();
      }
      if (text.equals("Delta time")) {
         String data = JOptionPane.showInputDialog("Enter delta t [s]");
         world.setDelta_t(Double.parseDouble(data));
      }
      if (text.equals("View Refresh time")) {
          String data = JOptionPane.showInputDialog("Enter Refresh Period [s]");
          world.setRefreshPeriod(Double.parseDouble(data));
      }
   }
}

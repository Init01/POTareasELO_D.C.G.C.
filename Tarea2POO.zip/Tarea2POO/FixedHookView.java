

import java.awt.*;
import java.awt.geom.*;
/** 
 * Vista de FixedHook
 */
public class FixedHookView {
   private final double width = 0;  // fixed point width
   private Color color = Color.GREEN;
   private Rectangle2D.Double shape = null;
   private FixedHook hook;
 /** 
 * Creacion de objeto en interfaz grafica
 * @param h FixedHook   
 */
public FixedHookView (FixedHook h){
       hook = h;
       shape = new Rectangle2D.Double(); 
   }
/** 
 * contains
 * @param x 
 * @param y 
 * @return view.contains(x,y) 
 */
   public boolean contains (double x, double y){
       return shape.getBounds2D().contains(x, y);
   }
/** 
 * setSelected
 * cambia color
 */
   public void setSelected (){
      color = Color.RED;
   }
/** 
 * setSelected
 * cambia color
 */
   public void setReleased() {
      color = Color.GREEN;
   }
/** 
 * Actualizacion de vista en la interfaz grafica
 * @param g
 */
   void updateView(Graphics2D g) {
      double radius = hook.getRadius();
      shape.setFrame(hook.getPosition()-radius, -radius, 2*radius, 2*radius);
      g.setColor(color);
      g.fill(shape);
   }
}

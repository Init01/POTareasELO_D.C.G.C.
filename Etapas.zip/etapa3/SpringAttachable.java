

public interface SpringAttachable {
  void attachSpring(Spring s);
  double getPosition();
}
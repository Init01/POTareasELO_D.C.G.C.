

import java.util.*;

public class FixedHook extends PhysicsElement implements SpringAttachable {
   private static int id=0;  // Ball identification number
   private final double radius;
   private double pos_t;     // current position at time t
   private ArrayList<Spring> springs;  // ArrayList can grow, arrays cannot. 

   private FixedHook() {   // nobody can create a block without state
     this(0.1,0);
   }
   public FixedHook(double radius, double position){
      super(id++);
        this.radius = radius;
      pos_t = position;
   }
   public double getRadius() {
      return radius;
   }

   public void computeNextState(double delta_t, MyWorld world) {

   }
   /*public boolean collide(Ball b) {
    if (b != null) {
        if (((b.getPosition()-pos_t)>0 && (b.getSpeed()-speed_t)<0) || ((b.getPosition()-pos_t)<0 && (b.getSpeed()-speed_t)>0)) {
            double b_pos = Double.parseDouble(b.getState());
            double this_pos = Double.parseDouble(this.getState());
        
            return (Math.abs(b_pos-this_pos) <= b.radius+this.radius);
        }
    }
    return false;
   
   }*/
   public void updateState() {

   }
   
   public String getDescription() {
        return "FixedHook_" + getId() + ":x";
   }
   public String getState() {
        return String.valueOf(pos_t);
   }

    public double getPosition() {
        return pos_t;
    }
    public void attachSpring(Spring s1) {
        //springs = new ArrayList<Spring>();
        //springs.add(s1);
        if (this.equals(s1.a_end)) {
            this.pos_t = s1.a_end.getPosition();
        }
        if (this.equals(s1.b_end)) {
            this.pos_t = s1.b_end.getPosition();
        }
    }
}
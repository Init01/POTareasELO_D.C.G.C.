import javax.swing.JFrame;
import javax.swing.*;
import javax.swing.JApplet;
import java.applet.AudioClip;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.*;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.*;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.*;
import org.jfree.data.general.DefaultPieDataset;

public class PhysicsLabApplet extends JApplet {

	public static AudioClip sound;

   public void init() {
//      setTitle("My Small and Nice Physics Laboratory");

      MyWorld world = new MyWorld();
      MyWorldView  worldView = new MyWorldView(world);
      world.setView(worldView);
      add(worldView); 
	
	graf1 g1 = new graf1(world);
          
      JSplitPane split1 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, worldView, g1.create_graf());
      split1.setOneTouchExpandable(true);
      split1.setDividerLocation(920);
      add(split1);

	sound = getAudioClip(getDocumentBase(), "buttondown.au");

	world.setpos_fix(Double.valueOf(getParameter("fixedHook.1")));
	world.setatr_ball1(getParameter("ball.1"));
	world.setatr_ball2(getParameter("ball.2"));
	world.setatr_ball3(getParameter("ball.3"));
	world.setatr_osc1(getParameter("oscillator.1"));


      LabMenuListener menu_l = new LabMenuListener(world);

      JMenuBar mb = new JMenuBar();
      
      JMenu menu = new JMenu ("Configuration");
      mb.add(menu);
      JMenu subMenu = new JMenu("Insert");  
      menu.add(subMenu);
      
      JMenuItem menuItem = new JMenuItem("Ball");
      menuItem.addActionListener(menu_l);
      subMenu.add(menuItem);
      menuItem = new JMenuItem("Fixed Hook");
      menuItem.addActionListener(menu_l);
      subMenu.add(menuItem);
      menuItem = new JMenuItem("Spring");
      menuItem.addActionListener(menu_l);
      subMenu.add(menuItem);
      menuItem = new JMenuItem("Oscillator");
      menuItem.addActionListener(menu_l);
      subMenu.add(menuItem);
      menuItem = new JMenuItem("My scenario");
      menuItem.addActionListener(menu_l);
      subMenu.add(menuItem);
       
      menu = new JMenu("MyWorld");
      mb.add(menu);
      menuItem = new JMenuItem("Start");
      menuItem.addActionListener(menu_l);
      menu.add(menuItem);
      menuItem = new JMenuItem("Stop");
      menuItem.addActionListener(menu_l);
      menu.add(menuItem);
      
      menuItem = new JMenuItem("Delete all");
      menuItem.addActionListener(menu_l);
      menu.add(menuItem);
      
      subMenu = new JMenu("Simulator");
      menuItem = new JMenuItem("Delta time");
      menuItem.addActionListener(menu_l);
      subMenu.add(menuItem);
      menuItem = new JMenuItem("View Refresh time");
      menuItem.addActionListener(menu_l);
      subMenu.add(menuItem);
      menu.add(subMenu);

      setJMenuBar(mb);    

	}

}

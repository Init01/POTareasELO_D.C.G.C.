import java.util.*;
import java.io.*;
import javax.swing.Timer;
import java.awt.event.*;

public class MyWorld implements ActionListener {
   private PrintStream out;
   
   private ArrayList<PhysicsElement> elements;  // array to hold everything in my world.
   private MyWorldView view;   // NEW
   private Timer passingTime;   // NEW
   private double t;        // simulation time
   private double delta_t;        // in seconds
   private double refreshPeriod;  // in seconds

	private double pos_fix;
	private double mas_ball1;
	private double rad_ball1;
	private double pos_ball1;
	private double spe_ball1;
	private double mas_ball2;
	private double rad_ball2;
	private double pos_ball2;
	private double spe_ball2;
	private double mas_ball3;
	private double rad_ball3;
	private double pos_ball3;
	private double spe_ball3;
	private double pos_osc1;
	private double amp_osc1;
	private double frc_osc1;

   
   public MyWorld(){
      this(System.out);  // delta_t= 0.1[ms] and refreshPeriod=200 [ms]
   }
   public MyWorld(PrintStream output){
      out = output;
      t = 0;
      refreshPeriod = 0.03;      // 60 [ms]
      delta_t = 0.00001;          // 0.01 [ms]
      elements = new ArrayList<PhysicsElement>();
      view = null;
      passingTime = new Timer((int)(refreshPeriod*1000), this);    
   }

   public void addElement(PhysicsElement e) {
      elements.add(e);
      view.repaintView();
   }
   public void setView(MyWorldView view) {
      this.view = view;
   }
   public void setDelta_t(double delta) {
      delta_t = delta;
   }
   public void setRefreshPeriod (double rp) {
      refreshPeriod = rp;
      passingTime.setDelay((int)(refreshPeriod*1000)); // convert from [s] to [ms]
   }
   public void start() {
      if(passingTime.isRunning()) return;
      passingTime.start();
      view.desableMouseListener();    
   }
   public void stop(){
      passingTime.stop();
      view.enableMouseListener();
   }
   
   public void actionPerformed (ActionEvent event) {  // like simulate method of Assignment 1, 
      double nextStop=t+refreshPeriod;                // the arguments are attributes here.
      for (; t<nextStop; t+=delta_t){
         for (PhysicsElement e: elements)
            if (e instanceof Simulateable) {
               Simulateable s = (Simulateable) e;
               s.computeNextState(delta_t,this); // compute each element next state based on current global state
            }
         for (PhysicsElement e: elements)  // for each element update its state. 
            if (e instanceof Simulateable) {
               Simulateable s = (Simulateable) e;
               s.updateState();            // update its state
            }
      }
      repaintView();
   }
   
   public void repaintView(){
      view.repaintView();
   }

   public Ball findCollidingBall(Ball me) {
      for (PhysicsElement e: elements)
         if ( e instanceof Ball) {
            Ball b = (Ball) e;
            if ((b!=me) && b.collide(me)) {
				PhysicsLabApplet.sound.play();
				return b;
			}
         }
      return null;
   }
 
   public ArrayList<PhysicsElement> getPhysicsElements(){
      return elements;
   }
   
   public PhysicsElement find(double x, double y) {
      for (PhysicsElement e: elements)
            if (e.contains(x,y)) return e;
      return null;
   }  
   public PhysicsElement findNext(PhysicsElement element, double x, double y) {
      for (int i = elements.indexOf(element)+1; i< elements.size(); i++) { // find
          if (elements.get(i).contains(x,y))    // next element in that position ahead in array
            return elements.get(i);
      }
      for (PhysicsElement e: elements)   // There was no element in that position ahead in array
          if (e.contains(x,y)) return e; // search for an element in that position from begining.
      return element;
   }  
   public SpringAttachable findAttachableElement(double x) {
      for (PhysicsElement e: elements)
         if (e instanceof SpringAttachable)
            if (e.contains(x,0)) return (SpringAttachable)e;
      return null;
   }  
   
   public void delete() {
       if (!passingTime.isRunning()) {
           elements.removeAll(elements);
           view.repaint();
       }    
   }

   public void setpos_fix(double val) {
       pos_fix = val;
   }
   public double getpos_fix() {
       return pos_fix;
   }
   public void setatr_ball1(String atr_b) {
	   String arr1[] = atr_b.split(";");
       mas_ball1 = Double.valueOf(arr1[0]);
	   rad_ball1 = Double.valueOf(arr1[1]);
	   pos_ball1 = Double.valueOf(arr1[2]);
	   spe_ball1 = Double.valueOf(arr1[3]);
   }
   public double getmas_ball1() {
       return mas_ball1;
   }
   public double getrad_ball1() {
       return rad_ball1;
   }
   public double getpos_ball1() {
       return pos_ball1;
   }
   public double getspe_ball1() {
       return spe_ball1;
   }

   public void setatr_ball2(String atr_b) {
	   String arr1[] = atr_b.split(";");
       mas_ball2 = Double.valueOf(arr1[0]);
	   rad_ball2 = Double.valueOf(arr1[1]);
	   pos_ball2 = Double.valueOf(arr1[2]);
	   spe_ball2 = Double.valueOf(arr1[3]);
   }
   public double getmas_ball2() {
       return mas_ball2;
   }
   public double getrad_ball2() {
       return rad_ball2;
   }
   public double getpos_ball2() {
       return pos_ball2;
   }
   public double getspe_ball2() {
       return spe_ball2;
   }

   public void setatr_ball3(String atr_b) {
	   String arr1[] = atr_b.split(";");
       mas_ball3 = Double.valueOf(arr1[0]);
	   rad_ball3 = Double.valueOf(arr1[1]);
	   pos_ball3 = Double.valueOf(arr1[2]);
	   spe_ball3 = Double.valueOf(arr1[3]);
   }
   public double getmas_ball3() {
       return mas_ball3;
   }
   public double getrad_ball3() {
       return rad_ball3;
   }
   public double getpos_ball3() {
       return pos_ball3;
   }
   public double getspe_ball3() {
       return spe_ball3;
   }

   public void setatr_osc1(String atr_o) {
	   String arr1[] = atr_o.split(";");
       pos_osc1 = Double.valueOf(arr1[0]);
	   amp_osc1 = Double.valueOf(arr1[1]);
	   frc_osc1 = Double.valueOf(arr1[2]);
   }
   public double getpos_osc1() {
       return pos_osc1;
   }
   public double getamp_osc1() {										
       return amp_osc1;
   }
   public double getfrc_osc1() {
       return frc_osc1;
   }

} 

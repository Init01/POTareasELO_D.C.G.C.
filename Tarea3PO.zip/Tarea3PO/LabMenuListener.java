import java.awt.event.*; 
import javax.swing.*;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class LabMenuListener implements ActionListener {
   private MyWorld  world;
   public LabMenuListener (MyWorld  w){
      world = w;
   }
   public void actionPerformed(ActionEvent e) {
      JMenuItem menuItem = (JMenuItem)(e.getSource());
      String text = menuItem.getText();
      
      // Actions associated to main manu options
      if (text.equals("My scenario")) {  // here you define Etapa2's configuration
         double mass = 1.0;      // 1 [kg] 
         double radius = 0.1;    // 10 [cm] 
         double position = 1.0;  // 1 [m] 
         double speed = 0.0;     // 0.5 [m/s]
		 Ball b0 = new Ball(world.getmas_ball1(), world.getrad_ball1(), world.getpos_ball1(), world.getspe_ball1());
		 Ball b1 = new Ball(world.getmas_ball2(), world.getrad_ball2(), world.getpos_ball2(), world.getspe_ball2());
		 Ball b2 = new Ball(world.getmas_ball3(), world.getrad_ball3(), world.getpos_ball3(), world.getspe_ball3());
         //Ball b = new Ball(mass, radius, position, speed);
		 FixedHook h0 = new FixedHook(world.getpos_fix());
		 Oscillator o0 = new Oscillator(world.getpos_osc1(), world.getamp_osc1(), world.getfrc_osc1());
		 //FixedHook h = new FixedHook(0.2);
//         Spring s = new Spring (0.5, 5);
//         s.attachAend(h);
//         s.attachBend(b);
         world.addElement(b0);
         world.addElement(b1);
         world.addElement(b2);
         world.addElement(h0);
         world.addElement(o0);
//         world.addElement(s);
      }
      if (text.equals("Ball")) 
        world.addElement(new Ball(1.0, 0.1, 1.2, 0));
      if (text.equals("Fixed Hook"))  
        world.addElement(new FixedHook(0.5));
      if (text.equals("Spring")) 
        world.addElement(new Spring(0.5, 5));
      if (text.equals("Oscillator")) 
        world.addElement(new Oscillator(0.5,0.1,0.5));

      // Actions associated to MyWorld submenu
      if (text.equals("Start"))   /* to be coded */
        world.start();
      
      if (text.equals("Stop"))    /* to be coded */
        world.stop();
      
      if (text.equals("Delete all")) {
          world.delete();
      }
      
      if (text.equals("Delta time")) {
         String data = JOptionPane.showInputDialog("Enter delta t [s]");
         world.setDelta_t(Double.parseDouble(data));
      }
      if (text.equals("View Refresh time")) {
         // to be coded
         String data = JOptionPane.showInputDialog("Enter view refresh time [s]");
         world.setRefreshPeriod(Double.parseDouble(data));
      }
   }
}

import javax.swing.JFrame;
import javax.swing.*;
import java.awt.Container;
import java.util.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.*;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.*;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.*;
import org.jfree.data.general.DefaultPieDataset;

public class graf1 extends JPanel {
    
    MyWorld world;
    ArrayList<Double> ec;
    ArrayList<PhysicsElement> elements;
    DefaultCategoryDataset datos;
    
    public graf1(MyWorld w1) {
        world = w1;
        ec = new ArrayList<Double>();
        elements = new ArrayList<PhysicsElement>();
    }    
    
    public void setdatos(DefaultCategoryDataset data) {
        datos = data;
    }
    public ChartPanel create_graf() {
        elements = world.getPhysicsElements();
        DefaultCategoryDataset data1 = new DefaultCategoryDataset();
        int i=0;
        for (PhysicsElement e:elements) {
            Ball b;
            double mass, speed;
            if (e instanceof Ball) {
                b = (Ball) e;
                mass = b.getMass();
                speed = b.getSpeed();
                ec.add((1/2)*mass*speed*speed);
            }
            
            data1.addValue(ec.get(i), "Ec", String.valueOf(ec.get(i)));
            System.out.println(ec.get(i));
            i++;
        }
        
        
//        DefaultCategoryDataset data1 = new DefaultCategoryDataset();
//        data1.addValue(10, "Ec", "1");
//        data1.addValue(20, "Ec", "2");
      
        JFreeChart chart = ChartFactory.createLineChart("grafico1", null, null, data1);
        ChartPanel chart1 = new ChartPanel(chart);
        return chart1;
    }
}
